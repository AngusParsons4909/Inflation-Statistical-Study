#Insert Packages
packages = c("tidyverse")
packages_to_install = packages[!(packages %in% installed.packages()[,"Package"])]
sapply(packages, library, character.only=TRUE)

#Get file
FileName = "C:/OneDrive/Desktop/R_Scripts/InflationData"
RawData <- read_csv(FileName, col_types = cols(value = col_double(),date = col_datetime()))

#Clean Data
Data <- RawData %>% drop_na(value, date)
Data$date <- as.Date(Data$date)
Data <- Data %>% arrange(date)

#Plot basic inflation % against time
#is kinda useless because inflation is meant to increase over time so its hard to compare the state of the economy
print(ggplot(Data, aes(x = date, y = value)) + geom_line(color = "blue") + labs(title = "Inflation Trend (1947-2023)", x = "Years", y = "Inflation %") + theme_light() + scale_x_date(date_breaks = "2 year", date_labels = "%Y"))


#tried to do deviation from the goal (2% inflation) but it didnt look very good/my calculation was wrong so I never used it
DeviationData <- Data %>% arrange(date) %>% mutate(PercentChange = value - lag(value), DeviationFromExpected = PercentChange - 2) 
#calculate the difference from the previous entry
DifferenceData <- Data %>% mutate(Difference = value - lag(value, default = first(value)))

#plot the difference over time
#this is much better because height indicates change in inflation which is what people actually mean when they talk about inflation.
#like covid was bad because inflation increased more than it usually does not because inflation was higher than usual
print(ggplot(DifferenceData, aes(x = date, y = Difference)) +
  geom_line(color = "red") +
  labs(title = "Difference from previous entry", 
       x = "Year", 
       y = "Difference %") +
  theme_light() +
  geom_hline(yintercept = 0, linetype = "solid", color = "blue") +
  scale_x_date(date_breaks = "2 years", date_labels = "%Y") +
  scale_y_continuous(breaks = seq(-10, 10, by = 1)))